"""
Project Hydra — Ghost Node Lambda
FR-01: Recursive deception (infinite fake directory tree)
FR-02: Two-strike vaccine enforcement via DynamoDB
"""

import json
import os
import random
import boto3
from datetime import datetime, timezone

# ── AWS clients ──────────────────────────────────────────────────────────────
dynamodb = boto3.resource("dynamodb")
table    = dynamodb.Table(os.environ["TABLE_NAME"])
NODE_ID  = os.environ.get("NODE_ID", "ghost-node-alpha")

# ── Bait catalogue (rotated randomly so every path looks unique) ──────────────
BAIT_FILES = [
    "db_config.php", "private_key.pem", "employee_salaries.csv",
    ".env", "id_rsa", "admin_passwords.txt", "backup_2024.sql",
    "api_secrets.json", "oauth_tokens.json", "s3_credentials.csv",
    "users_dump.sql", "shadow.bak", "ssl_cert.pem", "vpn_config.ovpn",
    "stripe_keys.txt", "master.key", "cloud_access.csv", "htpasswd",
]

BAIT_DIRS = [
    "backups", "credentials", "configs", "secrets", "admin",
    "internal", "private", "staging", "vault", "keys",
    "tokens", "archive", "legacy", "shadow", "restricted",
]

# ── Helpers ───────────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _fake_bait(path: str) -> dict:
    """Return a convincing fake directory listing for any path."""
    rng = random.Random(path)          # deterministic per-path so repeat visits look consistent
    files = rng.sample(BAIT_FILES, k=rng.randint(4, 8))
    dirs  = rng.sample(BAIT_DIRS,  k=rng.randint(3, 6))

    return {
        "status":    "200 OK",
        "path":      path,
        "node_id":   NODE_ID,
        "contents": {
            "directories": [f"{path.rstrip('/')}/{d}" for d in dirs],
            "files":       files,
        },
        "meta": {
            "server":    "Apache/2.4.51 (Ubuntu)",
            "generated": _now(),
            "warning":   "CONFIDENTIAL — Authorised access only",
        },
    }


def _get_record(ip: str):
    """Fetch the DynamoDB record for this IP, or None."""
    resp = table.get_item(Key={"ip_address": ip})
    return resp.get("Item")


def _log_visit(ip: str, path: str, ua: str, strike: int):
    """Upsert the IP record in DynamoDB."""
    table.put_item(Item={
        "ip_address":  ip,
        "captured_at": _now() if strike == 1 else table.get_item(
            Key={"ip_address": ip}).get("Item", {}).get("captured_at", _now()),
        "last_seen":   _now(),
        "node_id":     NODE_ID,
        "path":        path,
        "user_agent":  ua,
        "visits":      strike,
        "status":      "MALICIOUS" if strike >= 2 else "PROBER",
    })

# ── Main handler ──────────────────────────────────────────────────────────────

def lambda_handler(event, context):
    try:
        # ── Extract visitor metadata ─────────────────────────────────────────
        rc   = event.get("requestContext", {})
        ip   = rc.get("http", {}).get("sourceIp", "0.0.0.0")
        path = event.get("rawPath", "/")
        ua   = (event.get("headers") or {}).get("user-agent", "unknown")

        # ── FR-02: Check existing record ─────────────────────────────────────
        record = _get_record(ip)
        visits = int(record.get("visits", 0)) if record else 0

        new_visits = visits + 1

        # ── TWO-STRIKE: Block on second visit ────────────────────────────────
        if visits >= 1:
            # Already probed before — vaccinate
            _log_visit(ip, path, ua, new_visits)
            return {
                "statusCode": 403,
                "headers": {
                    "Content-Type": "application/json",
                    "X-Hydra-Node": NODE_ID,
                    "X-Hydra-Status": "VACCINATED",
                },
                "body": json.dumps({
                    "STATUS":  "VACCINATED",
                    "message": "Your IP has been permanently blacklisted.",
                    "ip":      ip,
                    "node_id": NODE_ID,
                }),
            }

        # ── FIRST VISIT: Log as Prober, serve bait ───────────────────────────
        _log_visit(ip, path, ua, new_visits)
        bait = _fake_bait(path)

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type":   "application/json",
                "X-Hydra-Node":   NODE_ID,
                "X-Hydra-Status": "PROBER-LOGGED",
                "X-Powered-By":   "Apache/2.4.51",
            },
            "body": json.dumps(bait, indent=2),
        }

    except Exception as exc:
        # Never reveal internals
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal server error"}),
        }
