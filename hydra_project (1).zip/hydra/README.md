# 🐍 Project Hydra — Cyber-Deception Honeypot

A **fully serverless, zero-cost** honeypot that traps attackers in a recursive fake
directory structure, blacklists repeat offenders, and visualises threat intelligence
on a live dashboard — all within AWS Free Tier.

---

## 📐 Architecture

```
Attacker Browser / Bot
        │
        ▼
┌───────────────────┐
│  AWS API Gateway  │  (HTTP API — free tier)
│   /{any path}     │
└────────┬──────────┘
         │
         ▼
┌────────────────────────────────────────────────────────┐
│  Ghost Node Lambda  (128 MB, 3 s timeout)              │
│                                                        │
│  1. Extract IP from requestContext                     │
│  2. Query DynamoDB for existing record                 │
│     • Visit 1  → serve bait JSON  (FR-01)              │
│     • Visit 2+ → return 403 VACCINATED  (FR-02)        │
│  3. Write/update record in DynamoDB                    │
└────────────────────┬───────────────────────────────────┘
                     │
                     ▼
          ┌─────────────────────┐
          │ DynamoDB            │
          │ Hydra_Vaccine_Hub   │  (Provisioned 1/1 — always free)
          └──────────┬──────────┘
                     │  (Scan)
                     ▼
          ┌─────────────────────┐
          │ Streamlit Dashboard │  (Streamlit Cloud — free)
          │  • Metrics          │
          │  • World map        │
          │  • Blacklist table  │
          └─────────────────────┘
```

---

## 🗂 File Structure

```
hydra/
├── template.yaml          ← SAM CloudFormation template (all AWS infra)
├── samconfig.toml         ← SAM deploy defaults
├── lambda/
│   └── lambda_function.py ← Ghost Node + Vaccine logic
└── dashboard/
    ├── dashboard.py       ← Streamlit real-time dashboard
    ├── requirements.txt   ← Python deps for Streamlit Cloud
    └── .streamlit/
        └── secrets.toml   ← Template — fill with CF Outputs
```

---

## 🚀 Step-by-Step Deployment

### Prerequisites (one-time install)

```bash
# 1. AWS CLI
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o AWSCLIV2.pkg
sudo installer -pkg AWSCLIV2.pkg -target /        # macOS
# or: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html

# 2. AWS SAM CLI
brew install aws-sam-cli                           # macOS
# or: https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html

# 3. Configure AWS credentials (use your root or IAM admin key)
aws configure
# Enter: Access Key ID, Secret Key, Region (e.g. us-east-1), output: json
```

---

### STEP 1 — Build the Lambda package

```bash
cd hydra/
sam build
```

Expected output:
```
Build Succeeded
Built Artifacts  : .aws-sam/build
```

---

### STEP 2 — Deploy everything to AWS

```bash
sam deploy --guided
```

Answer the prompts:

| Prompt | Answer |
|--------|--------|
| Stack Name | `project-hydra` |
| AWS Region | `us-east-1` (or your closest region) |
| Confirm changes | `Y` |
| Allow SAM to create IAM roles | `Y` |
| Disable rollback | `N` |
| Save arguments to config file | `Y` |

✅ After deploy finishes, **copy the Outputs section** — you need those values:

```
-----------------------------------------
Outputs
-----------------------------------------
HoneypotURL          https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com
DashboardAccessKeyId AKIAIOSFODNN7EXAMPLE
DashboardSecretKey   wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
DynamoTableName      Hydra_Vaccine_Hub
AWSRegion            us-east-1
-----------------------------------------
```

---

### STEP 3 — Test the honeypot

```bash
# Visit 1 — should return bait JSON (PROBER)
curl https://YOUR_HONEYPOT_URL/admin/credentials

# Visit 2 — should return 403 VACCINATED
curl https://YOUR_HONEYPOT_URL/admin/credentials

# Try any path — infinite fake directories
curl https://YOUR_HONEYPOT_URL/internal/backups/vault/keys
```

Expected first-visit response:
```json
{
  "status": "200 OK",
  "path": "/admin/credentials",
  "node_id": "ghost-node-alpha",
  "contents": {
    "directories": [
      "/admin/credentials/backups",
      "/admin/credentials/secrets",
      ...
    ],
    "files": [
      "private_key.pem",
      "db_config.php",
      "employee_salaries.csv",
      ...
    ]
  }
}
```

Expected second-visit response (HTTP 403):
```json
{
  "STATUS": "VACCINATED",
  "message": "Your IP has been permanently blacklisted.",
  "ip": "1.2.3.4",
  "node_id": "ghost-node-alpha"
}
```

---

### STEP 4 — Set up the Streamlit Dashboard

#### 4a — Push dashboard to GitHub

```bash
# Create a new GitHub repo (can be private — Streamlit Cloud supports private repos)
# Push only the dashboard folder:
git init
git add dashboard/
git commit -m "Hydra dashboard"
git remote add origin https://github.com/YOUR_USERNAME/hydra-dashboard.git
git push -u origin main
```

#### 4b — Deploy to Streamlit Community Cloud

1. Go to **https://share.streamlit.io** and sign in with GitHub.
2. Click **"New app"**.
3. Select your repo → branch `main` → main file: `dashboard/dashboard.py`.
4. Click **"Advanced settings"** → **Secrets** tab.
5. Paste the following (replacing values from CloudFormation Outputs):

```toml
AWS_ACCESS_KEY_ID     = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
AWS_REGION            = "us-east-1"
DYNAMODB_TABLE        = "Hydra_Vaccine_Hub"
```

6. Click **Deploy**. Your dashboard will be live at a `*.streamlit.app` URL in ~60 seconds.

---

### STEP 5 — Verify costs stay $0

| Service | Free tier limit | What Hydra uses |
|---------|----------------|-----------------|
| Lambda | 1M requests/month | Only fires on attacker visits |
| API Gateway (HTTP) | 1M requests/month (12 months) | Only fires on attacker visits |
| DynamoDB | 25 GB storage, 1 RCU/WCU provisioned | ~1 KB per attacker, capped at 1/1 |
| CloudWatch | 5 GB logs | Minimal (128 MB Lambda) |
| Streamlit Cloud | Unlimited for public/private repos | $0 always |

> ⚠️ **DynamoDB warning**: Make sure you selected **PROVISIONED** capacity when deploying.
> The SAM template enforces this. Do NOT change it to On-Demand.

---

## 🛡 Security Design

| Principle | Implementation |
|-----------|---------------|
| Least Privilege | Dashboard IAM user has **ReadOnly** DynamoDB access only |
| Stateless Ghost Node | Lambda stores nothing locally; all state in DynamoDB |
| Zero PII | Only IP address is stored (no personal data) |
| Fake files only | All bait files are generated in-memory; nothing is written to disk |
| Hard timeout | Lambda timeout = 3 s prevents infinite-loop abuse |

---

## 🧹 Teardown (delete all resources)

```bash
sam delete --stack-name project-hydra
```

This removes Lambda, API Gateway, DynamoDB table, and IAM user in one command.

---

## 🔧 Customisation

| What | Where | How |
|------|-------|-----|
| Add more bait files | `lambda/lambda_function.py` | Append to `BAIT_FILES` list |
| Change strike threshold | `lambda_function.py` | Change `visits >= 1` to `>= 2` for 3-strike |
| Add multiple ghost nodes | `template.yaml` | Duplicate `GhostNodeFunction` with different `NODE_ID` env var |
| Change region | `samconfig.toml` | Edit `region` field |
